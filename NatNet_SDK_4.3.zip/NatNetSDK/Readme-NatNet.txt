NaturalPoint, Inc. DBA OptiTrack

The NatNet SDK is a simple Client/Server networking SDK for sending and receiving
data from Motive across networks.  NatNet uses the UDP protocol in conjunction
with either multicasting or point-to-point unicasting for transmitting data.

Please refer to the NatNet API User's Guide for more information.
https://docs.optitrack.com/developer-tools/natnet-sdk

A list of changes made in each version can be found at the following website:
https://www.optitrack.com/support/downloads/developer-tools.html

The license for NatNet is included in this folder or at the following URL:
https://www.optitrack.com/about/legal/eula.html
